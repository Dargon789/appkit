export function Eth({ width, height }: { width?: number; height?: number }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
      <path
        d="M9.99839 1.48145V8.05333L15.5523 10.5356L9.99839 1.48145Z"
        fill="white"
        fillOpacity="0.9"
      />
      <path d="M9.99839 1.48145L4.44446 10.5356L9.99839 8.05333V1.48145Z" fill="white" />
      <path
        d="M9.99839 14.7937V19.2592L15.5556 11.5693L9.99839 14.7937Z"
        fill="white"
        fillOpacity="0.9"
      />
      <path d="M9.99839 19.2592V14.7937L4.44446 11.5693L9.99839 19.2592Z" fill="white" />
      <path
        d="M9.99839 13.76L15.5523 10.5356L9.99839 8.05333V13.76Z"
        fill="white"
        fillOpacity="0.8"
      />
      <path
        d="M4.44446 10.5356L9.99839 13.76V8.05333L4.44446 10.5356Z"
        fill="white"
        fillOpacity="0.9"
      />
    </svg>
  )
}
