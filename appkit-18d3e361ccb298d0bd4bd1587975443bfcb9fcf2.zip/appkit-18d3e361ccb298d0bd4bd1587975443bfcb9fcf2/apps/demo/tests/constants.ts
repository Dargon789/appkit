export const BASE_URL = process.env['BASE_URL']!
